import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HR_Data_System {

    private static final String LOGIN_PANEL = "loginPanel";
    private static final String EMPLOYEE_PANEL = "employeePanel";
    private static final String HR_MANAGER_PANEL = "hrManagerPanel";
    private static final String MANAGER_PANEL = "managerPanel";

    private static CardLayout cardLayout;
    private static JPanel cardPanel;

    public static void main(String[] args) {
        JFrame frame = new JFrame("HR SYSTEM");

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        JPanel loginPanelDetail = createLoginPanel(frame);
        cardPanel.add(loginPanelDetail, LOGIN_PANEL);

        // Create and add the back button panel
        JButton backButton = new JButton("Back");
        JPanel backButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        backButtonPanel.add(backButton);
        frame.add(backButtonPanel, BorderLayout.NORTH);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, LOGIN_PANEL);
            }
        });

        frame.add(cardPanel);

        // Set the size of the frame
        frame.setSize(800, 900);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private static JPanel createLoginPanel(JFrame frame) {
        JButton hrManagerButton = new JButton("HR Team");
        JButton employeeButton = new JButton("Employee");
        JButton managerButton = new JButton("Manager");

        JPanel loginPanelDetail = new JPanel(new FlowLayout(FlowLayout.CENTER));
        loginPanelDetail.add(hrManagerButton);
        loginPanelDetail.add(employeeButton);
        loginPanelDetail.add(managerButton);

        employeeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel employeeLoginPage = createEmployeeLoginPage(frame);
                cardPanel.add(employeeLoginPage, EMPLOYEE_PANEL);
                cardLayout.show(cardPanel, EMPLOYEE_PANEL);
            }
        });

        hrManagerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel hrManagerLoginPage = createHRLoginPage(frame);
                cardPanel.add(hrManagerLoginPage, HR_MANAGER_PANEL);
                cardLayout.show(cardPanel, HR_MANAGER_PANEL);
            }
        });

        managerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel managerLoginPage = new JPanel();
                JLabel labelManagerPage = new JLabel("Welcome Manager");
                managerLoginPage.add(labelManagerPage);

                cardPanel.add(managerLoginPage, MANAGER_PANEL);
                cardLayout.show(cardPanel, MANAGER_PANEL);
            }
        });

        return loginPanelDetail;
    }

    private static JPanel createEmployeeLoginPage(JFrame frame) {
        JPanel employeeLoginPage = new JPanel(new GridLayout(0, 1));
        JLabel labelEmployeeLoginPage = new JLabel("Employee Login");
        JTextField atosEmailAddressField = new JTextField(60);
        JTextField DasID = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Login");
        JLabel errorLabel = new JLabel("");

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String atosEmailAddress = atosEmailAddressField.getText();
                String DasID_Atos = DasID.getText();
                String password = new String(passwordField.getPassword());

                if ("employee".equals(DasID_Atos) && "password".equals(password)) {
                    JPanel welcomeEmployeePanel = new JPanel();
                    JLabel welcomeLabel = new JLabel("Welcome, Atos Employee!");
                    welcomeEmployeePanel.add(welcomeLabel);

                    cardPanel.add(welcomeEmployeePanel, EMPLOYEE_PANEL);
                    cardLayout.show(cardPanel, EMPLOYEE_PANEL);
                } else {
                    errorLabel.setText("Invalid credentials. Please try again.");
                }
            }
        });

        employeeLoginPage.add(labelEmployeeLoginPage);
        employeeLoginPage.add(new JLabel("DAS ID:"));
        employeeLoginPage.add(DasID);
        employeeLoginPage.add(new JLabel("Atos Email Address:"));
        employeeLoginPage.add(atosEmailAddressField);
        employeeLoginPage.add(new JLabel("Password:"));
        employeeLoginPage.add(passwordField);
        employeeLoginPage.add(loginButton);
        employeeLoginPage.add(errorLabel);

        return employeeLoginPage;
    }

    private static JPanel createHRLoginPage(JFrame frame) {
        JPanel hrLoginPage = new JPanel(new GridLayout(0, 1));
        JLabel labelHrLoginPage = new JLabel("HR Login");
        JTextField ID_Atos_HR_Manager = new JTextField(60);
        JTextField DasID = new JTextField(40);
        JTextField atosEmailAddress = new JTextField(60);
        JPasswordField passwordHrManager = new JPasswordField(60);
        JButton loginButton = new JButton("Login");
        JLabel errorLabel = new JLabel(" ");

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idNumber = ID_Atos_HR_Manager.getText();
                String atosDasId = DasID.getText();
                String atosEmail = atosEmailAddress.getText();
                String password = new String(passwordHrManager.getPassword());

                if ("employee".equalsIgnoreCase(idNumber) && "DasID".equalsIgnoreCase(atosDasId)
                        && "Email".equalsIgnoreCase(atosEmail) && "password".equalsIgnoreCase(password)) {
                    JPanel welcomeHrManager = new JPanel();
                    JLabel welcomeLabel = new JLabel("Welcome HR Team");
                    welcomeHrManager.add(welcomeLabel);

                    cardPanel.add(welcomeHrManager, HR_MANAGER_PANEL);
                    cardLayout.show(cardPanel, HR_MANAGER_PANEL);
                } else {
                    errorLabel.setText("Invalid Credentials");
                }
            }
        });

        hrLoginPage.add(labelHrLoginPage);
        hrLoginPage.add(new JLabel("ID Number:"));
        hrLoginPage.add(ID_Atos_HR_Manager);
        hrLoginPage.add(new JLabel("DAS ID:"));
        hrLoginPage.add(DasID);
        hrLoginPage.add(new JLabel("Atos Email Address:"));
        hrLoginPage.add(atosEmailAddress);
        hrLoginPage.add(new JLabel("Password:"));
        hrLoginPage.add(passwordHrManager);
        hrLoginPage.add(loginButton);
        hrLoginPage.add(errorLabel);

        return hrLoginPage;
    }
}
